module github.com/rfjakob/gocryptfs/v2

go 1.26.0

require (
	github.com/aperturerobotics/jacobsa-crypto v1.1.0
	github.com/hanwen/go-fuse/v2 v2.12.1-0.20261018182834-2d50fff207d7
	github.com/moby/sys/mountinfo v0.7.2
	github.com/pkg/xattr v0.4.9
	github.com/rfjakob/eme v1.2.0
	github.com/sabhiram/go-gitignore v0.0.0-20210923224102-525f6e181f06
	github.com/spf13/pflag v1.0.10
	golang.org/x/crypto v0.58.0
	golang.org/x/sys v0.49.0
	golang.org/x/term v0.47.0
	golang.org/x/text v0.43.0
)
